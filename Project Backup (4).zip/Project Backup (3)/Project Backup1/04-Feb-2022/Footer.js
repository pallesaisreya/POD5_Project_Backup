import React from "react";
//import "./SuggestionList.css";
import logo from "./dd1.png";
const Footer = () => {
return (
    <div>

    <title>Insert title here</title>
  </div>
          
);
};
export default Footer;