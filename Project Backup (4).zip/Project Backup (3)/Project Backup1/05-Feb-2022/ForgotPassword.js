import React from "react";
import "./ForgotPassword.css";
import logo from "./fp.png";
import logo1 from "./f2.png";



const ForgotPassword = ()=> {
return (



<div>

<title>Forgot Password</title>
<div className="wrapper">
<div id="formContent">
<img src={logo} alt="img"></img>
<form className="box">
<h4>Forgot Password</h4><br/><br/>
<input type="email" name="" placeholder="Enter UserName" id="username" required/><br/><br/>
<input type="submit" value="Go"/>

</form>
</div>
</div>
</div>
)
}



export default ForgotPassword;